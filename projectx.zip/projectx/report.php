<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/admin-table.css">
		<link rel="stylesheet" href="css/footer.css">
	</head>
	<body>
		<?php include "navbar.php";?>

		<table class="tb-data">
			<thead>
				<tr>
					<th class="theadtd">Product</th>
					<th class="theadtd">Quantity</th>
					<th class="theadtd">Amount</th>
				</tr>
			</thead>
			<tbody>
				<form>
					<br>
					<?php
						$sql ="SELECT pp.name 'product', SUM(sol.qty) 'quantity', SUM(sol.total) 'amount' FROM sale_order so LEFT JOIN sale_order_line sol on sol.so_id = so.id LEFT JOIN product pp on pp.id = sol.product_id WHERE so.status='Validated' GROUP BY product_id;";
						if($result=$mysqli->query($sql)){
							while($row=$result->fetch_assoc()){
								echo "<tr><td class='theadtd'><span align='center' style='display:block;'>".$row['product']."</span></td>"
									."<td class='theadtd'><span align='center' style='display:block;'>".$row['quantity']."</span></td>"
									."<td class='theadtd'><span align='center' style='display:block;'>".$row['amount']."</span></td><tr>";
									  
							}
						}
					?>
				</form>
			</tbody>
		</table>


		<?php include "footer.php";?>