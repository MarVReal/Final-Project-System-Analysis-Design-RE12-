<?php include "conn.php";?>
<?php
	//add to cart
	if(isset($_GET['modal-header-product'])&&isset($_GET['modal-header-desc'])&&isset($_GET['modal-body-price'])&&isset($_GET['modal-body-qty'])&&isset($_GET['modal-header-id'])){
		if($_GET['modal-body-qty']!=''){
			$total = $_GET['modal-body-price'] * $_GET['modal-body-qty'];

			$exist = "SELECT * FROM cart WHERE customer_id = ".$_SESSION['customer_id']." AND product_id = ".$_GET['modal-header-id']." AND state = 'draft';";
			$sql = '';

			if($result=$mysqli->query($exist))
				if($result->num_rows >0)
					while($row=$result->fetch_assoc())
						$sql = "UPDATE cart SET qty = ".$row['qty']."+".$_GET['modal-body-qty']." WHERE customer_id = ".$_SESSION['customer_id']." AND product_id = ".$_GET['modal-header-id']." AND state = 'draft';";
			
				else
					$sql = "INSERT INTO cart(customer_id, product_id,qty,price,total) VALUES(".$_SESSION['customer_id'].",(SELECT id FROM product WHERE name = '".$_GET['modal-header-product']."'),".$_GET['modal-body-qty'].",".$_GET['modal-body-price'].",".$total.");";
				

			$result=$mysqli->query($sql);
			header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/category.php", true, 303);
			exit;
		}
		else{
			header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/category.php", true, 303);
			exit;
		}
	}

	//remove an item from the cart
	if(isset($_GET["remo"])){
		$sql = "DELETE FROM cart WHERE customer_id = ".$_SESSION['customer_id']." AND product_id = ".$_GET['remo']." AND state = 'draft';";
		echo $sql;
		if($mysqli->query($sql)===true)
			header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/cart.php", true, 303);
		exit;
		
	}

	//checkout
	if(isset($_GET['quant'])&&isset($_GET['total'])&&isset($_GET['cart_prod_id'])){

		$create_so = "INSERT INTO sale_order(so_number, qty, total, customer_id, status) VALUES ((SELECT CONCAT('SO',COUNT(sale_table.id)+1) FROM (select * from sale_order) as sale_table),"."(SELECT SUM(qty) FROM cart WHERE customer_id = ".$_SESSION['customer_id']." AND state = 'draft')".",".$_GET['total'].", ".$_SESSION['customer_id'].",'Draft');";


		$get_so = "SELECT id FROM sale_order WHERE customer_id = ".$_SESSION['customer_id']." AND  status = 'draft' ORDER BY create_date DESC LIMIT 1;";

		$checkout = "UPDATE cart SET state = 'done' WHERE customer_id = ".$_SESSION['customer_id'].";";

		$get_line_items = "SELECT product_id, qty, price, total FROM cart WHERE customer_id = ".$_SESSION['customer_id']." AND  state = 'draft';";

		$result=$mysqli->query($create_so);

		if($result=$mysqli->query($get_so)){
			while($row=$result->fetch_assoc()){
				if($result1=$mysqli->query($get_line_items)){
					while($row1=$result1->fetch_assoc()){
						$create_so_line = "INSERT INTO sale_order_line(so_id,product_id, qty, price, total) VALUES(".$row['id'].",".$row1['product_id'].",".$row1['qty'].",".$row1['price'].",".$row1['total'].");";
						echo $create_so_line;
						$result2=$mysqli->query($create_so_line);
					}
				}
			}
		}

		$result=$mysqli->query($checkout);

		

		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/cart.php", true, 303);
		exit;
	}

	//validate transaction
	if(isset($_GET['valid_trans'])) {
		//move the status of sale_order
		$validate = "UPDATE sale_order SET status='In Progress' WHERE id=".$_GET['valid_trans'].";";
		$result=$mysqli->query($validate);

		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/transaction.php", true, 303);
		exit;
	}

	//validate sales
	if(isset($_GET['valid_sales'])) {
		$checker = 0;
		$so = "UPDATE sale_order SET status = 'validated' WHERE id = ".$_GET['valid_sales'].";";
		$so_line = "SELECT * FROM sale_order_line WHERE so_id = ".$_GET['valid_sales'].";";
		$inv_count = "SELECT sq.id sq_id, sq.product_id sq_prod_id, sq.qty sq_qty, sol.qty sol_qty FROM stock_quant sq LEFT JOIN sale_order_line sol ON sq.product_id = sol.product_id LEFT JOIN sale_order so ON so.id = sol.so_id WHERE so.id =".$_GET['valid_sales'].";";

		//check inventory if all products are available
		if($result=$mysqli->query($inv_count)){;
			while($row=$result->fetch_assoc()){
				if($row['sq_qty'] >= $row['sol_qty']){
					// echo "<br>". $row["sq_prod_id"];
					$checker = 1;	
				}			
				else{
					$checker = 0;
					break;
				}
			}
		}

		//update inventory
		// echo "CHECKER = ".$checker;
		if($checker==1){	
			if($result=$mysqli->query($inv_count)){
				while($row=$result->fetch_assoc()){
					$update = "UPDATE stock_quant SET qty=".$row['sq_qty']."-".$row['sol_qty']." WHERE id=".$row['sq_id'].";";
					$result1=$mysqli->query($update);
				}
			}
		}		
		else{
			//do not update. return to sales.php
			// echo "<br>out";
			header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/sales.php", true, 303);
			exit;
		}
		//move the status of sale_order
		$validate = "UPDATE sale_order SET status='Packed' WHERE id=".$_GET['valid_sales'].";";
		$result=$mysqli->query($validate);

		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/sales.php", true, 303);
		exit;
	}

	//validate pack
	if(isset($_GET['valid_pack'])) {
		//move the status of sale_order
		$validate = "UPDATE sale_order SET status='Shipped' WHERE id=".$_GET['valid_pack'].";";
		$result=$mysqli->query($validate);

		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/packed.php", true, 303);
		exit;
	}

	//done ship
	if(isset($_GET['valid_ship'])) {
		//move the status of sale_order
		$validate = "UPDATE sale_order SET status='Validated' WHERE id=".$_GET['valid_ship'].";";
		$result=$mysqli->query($validate);

		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/shipped.php", true, 303);
		exit;
	}

	//all sales filter
	if(isset($_GET['status'])){
		//create default sql
		$sql="SELECT so.id so_id, so.so_number so_num, so.create_date order_date, users.name customer, so.qty quant, so.total total, so.status state FROM sale_order so LEFT JOIN users on users.id = so.customer_id ";

		if($_GET['status']!='default')
			$sql =  $sql."WHERE so.status = '".$_GET['status']."';";

		$_SESSION['search']=$sql;
		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/all_sales.php", true, 303);
		exit;
	}

	//update inventory by the user
	if(isset($_GET['modal-body-qty'])&&isset($_GET['modal-inv-id'])){
		$sql = "UPDATE stock_quant SET qty=".$_GET['modal-body-qty']."+(SELECT SUM(qty) FROM (SELECT * FROM stock_quant WHERE product_id=".$_GET['modal-inv-id'].")as sq) WHERE product_id=".$_GET['modal-inv-id'].";";
		echo $sql;
		$result=$mysqli->query($sql);

		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/inventory.php", true, 303);
		exit;
	}

	//registration form
	if(isset($_GET['register'])){
		if(isset($_GET['fname'])&&isset($_GET['username'])&&isset($_GET['mobile'])&&isset($_GET['email'])&&isset($_GET['address'])&&isset($_GET['password'])){
			$username = $_GET['username'];
			$email = $_GET['email'];
			$password = ($_GET['password']);
			$address = $_GET['address'];
			$mobile = $_GET['mobile'];
			$fname = $_GET['fname'];


			$Select = "SELECT email FROM users WHERE email = ? LIMIT 1;";
			$Insert = "INSERT INTO users(username, email, password, address, mobile_number, name) VALUES(?,?,?,?,?,?);";

			#Sanitize query for prevention of SQL Injection
			#PREPARED STATEMENT
			$stmt = $mysqli->prepare($Select);
			$stmt->bind_param("s", $email);
			$stmt->execute();
			$stmt->bind_result($resultEmail);
			$stmt->store_result();
			$stmt->fetch();
			$rnum = $stmt->num_rows;

			if ($rnum == 0) {
				$stmt->close();

				$stmt = $mysqli->prepare($Insert);
				$stmt->bind_param("ssssis",$username, $email, $password, $address, $mobile, $fname);
				if ($stmt->execute()) {
					echo "New record inserted sucessfully.";
					#do some stuffs
				}
				else {
					echo $stmt->error;
				}
			}
			else {
				echo '<script>alert("Email already taken")</script>';
			}
			$stmt->close();
		}
		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/login.php", true, 303);
		exit;
	}

	//search food
	if(isset($_GET['search'])){
		$sql = "SELECT * FROM product WHERE name LIKE '%".$_GET['search']."%';";

		$result=$mysqli->query($sql);

		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/sample.php", true, 303);
		exit;
	}

	//edit profile
	if(isset($_GET['fname'])&&isset($_GET['uname'])&&isset($_GET['mobile'])&&isset($_GET['email'])&&isset($_GET['address'])&&isset($_GET['password'])){
		$sql = "UPDATE users SET name='".$_GET['fname']."',username='".$_GET['uname']."',password='".$_GET['password']."',address='".$_GET['address']."',mobile_number='".$_GET['mobile']."',email='".$_GET['email']."' WHERE id = ".$_SESSION['customer_id'].";";

		$result=$mysqli->query($sql);
		header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/temp_prof.php", true, 303);
		exit;
	}

	
?>
