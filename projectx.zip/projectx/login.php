<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<title>Login|Register</title>
		<meta charset="UTF-8">
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/login.css?v=<php? echo time();?">
	</head>
	<body>
		<?php include "navbar.php"?>
		<div class="hero">
			<div class="form-box">
				<div class="button-box">
					<div id="btn"></div>
						<button type="button" class="toggle-btn" onclick="login()">  Login</button>
						<button type="button" class="toggle-btn" onclick="register()">   Register</button>
				</div>
				<div class="social-icons">
					<img src="images/f.jpg">
					<img src="images/g.jpg"/>
				</div>
				<form action="verify.php" method="GET" id="login" class="input-group" autocomplete="off">
					<input type="text" class="input-field" id="username" name="username" placeholder="User ID" required>
					<input type="password" class="input-field" id="password" name="password" placeholder="Enter Password" required>
					<input type="submit" value="Login" class="submit-btn">
					<span class="invalid" id="inv-info">
						<?php
							//code to verify if user enter credentials correctly
							if(isset($_SESSION['verify'])){
								if($_SESSION['verify']==false){
									echo 'Invalid Username or Password';
									unset($_SESSION['verify']);
								}
							}
						?>	
					</span>
				</form>

				<form action="query.php" method="GET" id="register" class="input-group">
					<input type="text" class="input-field" name="fname" placeholder="Full name"required>
					<input type="text" class="input-field" name="address" placeholder="Address"required>
					<input type="text" class="input-field" name="mobile" placeholder="Phone number"required>
					<input type="text" class="input-field" name="username" placeholder="User ID"required>
					<input type="text" class="input-field" name="email" placeholder="Email Address"required>
					<input type="password" class="input-field" name="password" placeholder="Password"required>
					<input type="checkbox" class="check-box" name="terms"><span>I agree to the terms and conditions</span> 
					<input type="submit" value="Register" class="submit-btn" name="register">
				</form>
			</div>
		</div>
		<script>
			var x = document.getElementById("login");
			var y = document.getElementById("register");
			var z = document.getElementById("btn");

			function register(){
				x.style.left = "-400px";
				y.style.left = "50px";
				z.style.left ="110px";
			}
			function login(){
				x.style.left = "50px";
				y.style.left = "450px";
				z.style.left ="0";
			}
		</script>
	</body>
</html>