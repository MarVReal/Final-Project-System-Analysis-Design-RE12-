<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="css/admin-table.css">
	</head>
	<body>
		<?php include "navbar.php";?>

		<table class="tb-data">
			<thead>
				<tr>
					<th>Image</th>
					<th>Product</th>
					<th>Description</th>
					<th>Quantity</th>
					<th>Price</th>
					<th>Sub Total</th>
				</tr>
			</thead>
			<tbody>
				<form action="query.php" action="GET">
					<?php
						if(isset($_GET['trans_so_id'])){
							$sql ="SELECT product.img_path img_path, product.id prod_id, product.name product, product.description description, sol.qty qty, sol.price price, sol.total total FROM sale_order so LEFT JOIN sale_order_line sol ON sol.so_id = so.id LEFT JOIN product ON product.id = sol.product_id WHERE so.id =".$_GET['trans_so_id'].";";
							// echo $sql;	
							if($result=$mysqli->query($sql)){
								while($row=$result->fetch_assoc()){
									echo "<tr><td><input type='hidden' name='sale_prod_id' class='sale_prod_id' value='".$row['prod_id']."'><img src='".$row['img_path']."'></td>"
									  ."<td><input type='text' class='name' name='name' value='".$row['product']."' style='border:none; text-align:center;' readable></td>"
									  ."<td><input type='text' class='desc' name='desc'value='".$row['description']."' style='border:none; text-align:center;' readonly></td>"
									  ."<td><input type='text' class='quant' name='quant' value='".$row['qty']."' style='border:none; text-align:center;' readonly></td>"
									  ."<td><input type='text' class='price' name='price' value='".$row['price']."' style='border:none; text-align:center;' readonly></td>"
									  ."<td><input type='text' class='total' name='total' value='".$row['total']."' style='border:none; text-align:center;' readonly></td>";

								}
							}
						}
					?>
				</form>
			</tbody>
		</table>
		<span id='test'><span>
		<script>
			var sum = 0;
			var num_rows = document.getElementById('tb-data').rows.length-1;
			console.log(num_rows);

			for(var index=0;index<num_rows;index++){
				sum += parseInt(document.getElementsByClassName('total')[index].value);
			}
			document.getElementById('test').innerHTML = sum;

		</script>

		<?php include "footer.php";?>