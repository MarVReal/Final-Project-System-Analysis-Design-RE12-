<?php include "conn.php";?>
<?php
	if(isset($_GET['modal-header-product'])&&isset($_GET['modal-header-desc'])&&isset($_GET['modal-body-price'])&&isset($_GET['modal-body-qty'])&&isset($_GET['modal-header-id'])){
		if($_GET['modal-body-qty']!=''){
			$total = $_GET['modal-body-price'] * $_GET['modal-body-qty'];

			$exist = "SELECT * FROM cart WHERE customer_id = ".$_SESSION['customer_id']." AND product_id = ".$_GET['modal-header-id']." AND state = 'draft';";
			$sql = '';

			if($result=$mysqli->query($exist))
				if($result->num_rows >0)
					while($row=$result->fetch_assoc())
						$sql = "UPDATE cart SET qty = ".$row['qty']."+".$_GET['modal-body-qty']." WHERE customer_id = ".$_SESSION['customer_id']." AND product_id = ".$_GET['modal-header-id']." AND state = 'draft';";
			
				else
					$sql = "INSERT INTO cart(customer_id, product_id,qty,price,total) VALUES(".$_SESSION['customer_id'].",(SELECT id FROM product WHERE name = '".$_GET['modal-header-product']."'),".$_GET['modal-body-qty'].",".$_GET['modal-body-price'].",".$total.");";
				

			$result=$mysqli->query($sql);
			header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/category.php", true, 303);
		}
		else{
			header("Location: http://".$_SERVER['HTTP_HOST']."/projectx/category.php", true, 303);
			exit;
		}
	}
?>