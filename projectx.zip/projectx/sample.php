<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="css/admin-table.css">
	</head>
	<body>
		<?php include "navbar.php";?>
		<section class="food-search text-center">
			<div class="container">
				<form action="sample.php" method="GET">
					<input type ="search" name="search" placeholder="Search for Food...">
					<input type ="submit" name="submit" value="Search" class="btn btn-primary">
				</form>
			</div>
		</section>

		<table class="tb-data">
			<thead>
				<tr>
					<th>Image</th>
					<th>Product</th>
					<th>Description</th>
					<th>Price</th>
				</tr>
			</thead>
			<tbody>
				<form action="#">
					<br>
					<?php
						$sql = "SELECT * FROM product WHERE name LIKE '%".$_GET['search']."';";
						if($result=$mysqli->query($sql)){
							while($row=$result->fetch_assoc()){
								echo "<tr><td class='text-center 'theadtd''><input type='hidden' name='prod_id' class='prod_id' value='".$row['id']."'><img src='".$row['img_path']."'></td>"
									."<td class='text-center theadtd'><input type='text' class='name' name='name' value='".$row['name']."' style='outline:none; border:none; text-align:center;' readable></td>"
									."<td class='text-center theadtd'><input type='text' class='desc' name='desc'value='".$row['description']."' style='outline:none; border:none; text-align:center;' readonly></td>"
									."<td class='text-center theadtd'><input type='text' class='price' name='price' value='".$row['price']."' style='outline:none; border:none; text-align:center;' readonly></td></tr>";
							}
						}
						// echo "<td><input type='submit' value='Checkout'></td></tr>"
					?>
				</form>
			</tbody>
		</table>


		<?php include "footer.php";?>