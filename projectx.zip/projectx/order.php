<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/menu.css">
		<link rel="stylesheet" href="css/footer.css">
	</head>
	<body>
		<?php include "navbar.php"?>
		<section class="categories" id="try">
			<div class="nav.container">
				<h2 class="text-center">Categories</h2><br>
					<form method="POST" class="box-3 float-container" action="category.php">
						<input type="hidden" name="category" value="1">
						<img src="images\momo.jpg" alt="Dimsum Products" class="img-responsive img-curve">
						<button type="submit" action="category.php"> Dimsum Products </button>
						<!-- <h3 class="float-text text-white text-center">Dimsum Products</h3> -->
					</form>

					<form method="POST" class="box-3 float-container" action="category.php">
						<input type="hidden" name="category" value="2">
						<img src="images\pic1.jpg" alt="Dimsum Products" class="img-responsive img-curve">
						<button type="submit" action="category.php"> Berry Products </button>
						<!-- <h3 class="float-text text-white text-center">Frozen Berries</h3> -->
					</form>

	
					<form method="POST" class="box-3 float-container" action="category.php">
						<input type="hidden" name="category" value="3">
						<img src="images\s1.jpg" alt="Dimsum Products" class="img-responsive img-curve">
						<button type="submit" action="category.php"> Meat Products </button>
						<!-- <h3 class="float-text text-white text-center">Meat Products</h3> -->
					</form>
				<div class="clearfix"></div>
			</div>
		</section>
<?php include "footer.php";?>