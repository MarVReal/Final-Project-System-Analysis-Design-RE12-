<?php include "conn.php";?>
<?php
	if(isset($_SESSION['verify'])){
		unset($_SESSION['verify']);
	}
	session_unset();
	header("Location: login.php");
?>