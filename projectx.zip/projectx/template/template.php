<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/footer.css">
	</head>
	<body>
		<?php include "navbar.php"?>
	<?php include "footer.php"?>