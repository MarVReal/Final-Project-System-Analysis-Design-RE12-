<section class="Navbar">
	<div class="nav-container">
		<div class="logo">
			<a href="index.php">
				<img src="images\logo.png" alt="Frozen Goodies MNL Logo" class="img-responsive">
			</a>
		</div>
		<div class="nav-set">
			<ul class="banner-ul">
				<?php

					$s ='<li><a href = "index.php" class="nav-set-link">Home</a></li>'.
						'<li><a href = "contact.php" class="nav-set-link">Contact Us</a></li>'.
						'<li><a href = "about.php" class="nav-set-link">About Us</a></li>'.
						'<li><a href = "login.php" class="nav-set-link">Log In</a></li>';
					//ONCE LOGGED IN
					if(isset($_SESSION['verify'])&&isset($_SESSION['admin'])){
						if($_SESSION['verify']){
							if($_SESSION['admin']==0){
								$s ='<li><a href = "transaction.php" class="nav-set-link">Transaction</a></li>'
								 	.'<li><a href = "sales.php" class="nav-set-link">Sales</a></li>'
								 	.'<li><a href = "packed.php" class="nav-set-link">Packed</a></li>'
								 	.'<li><a href = "shipped.php" class="nav-set-link">Shipped</a></li>'
								 	.'<li><a href = "all_sales.php" class="nav-set-link">All Sales</a></li>'
									.'<li><a href = "inventory.php" class="nav-set-link">Inventory</a></li>'
									.'<li><a href = "report.php" class="nav-set-link">Reports</a></li>'
									.'<li><a href = "logout.php" class="nav-set-link">Log Out</a></li>';
							}
							else{
								$s ='<li><a href = "index.php" class="nav-set-link">Home</a></li>'. 
									'<li><a href = "cart.php" class="nav-set-link">Cart</a></li>'.
									'<li><a href = "order.php" class="nav-set-link">Order Now</a></li>'.
									// '<li><a href = "trackorder.php" class="nav-set-link">Track Your Order</a></li>'.
									'<li><a href = "contact.php" class="nav-set-link">Contact Us</a></li>'.
									'<li><a href = "about.php" class="nav-set-link">About Us</a></li>'.
									'<li><a href = "temp_prof.php" class="nav-set-link">Profile</a></li>'.
									'<li><a href = "logout.php" class="nav-set-link">Log Out</a></li>';
							}
						}
					}
					echo $s;
				?>
			</ul>
		</div>
	</div>
</section>