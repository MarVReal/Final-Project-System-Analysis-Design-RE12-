<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/contactus.css">
		<link rel="stylesheet" href="css/footer.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet">
	</head>
	<body>
		<?php include "navbar.php"?>
		<section class="bulk">
        <div class="nav.container text-left">
            <div class="contact-section">
                <p class="strongfont text-center">Bulk Orders?<br>Contact Us!</p><br>
                <form class="contact-form" action="index.html" method="post">
                  <input type="text" class="contact-form-text" placeholder="Your name">
                  <input type="email" class="contact-form-text" placeholder="Your email">
                  <input type="text" class="contact-form-text" placeholder="Your phone">
                  <textarea class="contact-form-text" placeholder="Your message"></textarea>
                  <input type="submit" class="contact-form-btn" value="Send">
                </form>
            </div>
        </div>
    </section>
<?php include "footer.php";?>