<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/admin-table.css">
		<link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="css/inv-modal.css">
		<script src="scripts/jquery-3.2.1.min.js"></script>
	</head>
	<body>
		<?php include "navbar.php";?>

		<table class="tb-data">
			<thead>
				<tr>
					<th class="theadtd">Image</th>
					<th class="theadtd">Product Name</th>
					<th class="theadtd">Description</th>
					<th class="theadtd">Quantity</th>
				</tr>
			</thead>
			<tbody>
				<form action="query.php" action="GET">
					<br>
					<span> Add an item</span>
					<?php

						$sql="SELECT pp.img_path 'img_path', pp.id 'id', pp.name 'product', pp.description 'description', sq.qty 'quantity' FROM stock_quant sq LEFT JOIN product pp on sq.product_id = pp.id";

						if($result=$mysqli->query($sql)){
							while($row=$result->fetch_assoc()){
								echo "<tr><td class='theadtd text-center'><input type='hidden' class='prod_id' value='".$row['id']."'><label for='click' class='click-me'><img src='".$row['img_path']."'id='imgs'></label></td>"
								."<td class='theadtd text-center'><input type='text' class='textarea name' value='".$row['product']."' style=' outline:none; border:none; text-align:center;' readonly></td>"
								."<td class='theadtd text-center'><input type='text' class='textarea desc' value='".$row['description']."' style=' outline:none; border:none; text-align:center;' readonly></td>"
								."<td class='theadtd text-center'><input type='text' class='textarea quant' value='".$row['quantity']."' style=' outline:none; border:none; text-align:center;' readonly></td></tr>";
							}
						}
					?>
				</form>
			</tbody>
		</table>

		<form class="center" method="GET" action="query.php">
			<input type="checkbox" id="click">
			<div class="content">
				<div class="header">
					<input class="fontz" type="text" id="modal-header-product" name="modal-header-product">
					<input class="fontz" type="text" id="modal-header-desc" name="modal-header-desc">
					<input type="hidden" id="modal-header-id" name="modal-header-id">
				</div>
				<br>
				<input class="area position1" type="number" id="qty" name="modal-body-qty" size="3">
				<div class="line"></div>
				<label for="click" class="close-btn">Close</label>
				<input type="submit" class="add-btn" value="Update">
			</div>
		</form>
		<script>
			var s = $('img[id=imgs]');
			$(s).click(function(){
				modal($(this).closest('tr').index());
			})
			function modal(index){
				var product_id = document.getElementsByClassName('prod_id')[index-1].value;
				var product = document.getElementsByClassName('name')[index-1].value;
				var description = document.getElementsByClassName('desc')[index-1].value;

				document.getElementById('modal-header-id').value = product_id;
				document.getElementById('modal-header-product').value = product;
				document.getElementById('modal-header-desc').value = description;

				console.log(product_id);
				console.log(product);
				console.log(description);
			}
		</script>


		<?php include "footer.php";?>