<?php include "conn.php";?>

<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="css/modal.css">
		<link rel="stylesheet" href="css/category.css">
		<script src="scripts/jquery-3.2.1.min.js"></script>

	</head>
	<body>
		<?php include "navbar.php"?>
		<table class="tb-data">
			<thead>
				<tr>
					<th>Image</th>
					<th>Product</th>
					<th>Description</th>
					<th>Price</th>
					<!-- <th>Quantity</th> -->
				</tr>
			</thead>
			<tbody>
				<form action="cart.php" method="GET">
					<?php
						$sql = '';
						if(!isset($_POST['category'])){
							$sql="SELECT id, name,description,price,img_path FROM product WHERE category_id = ".$_SESSION['categ_id'];
						}
						else{
							$sql="SELECT id, name,description,price,img_path FROM product WHERE category_id = ".$_POST['category'];
							$_SESSION['categ_id'] = $_POST['category'];
						}

						if($result=$mysqli->query($sql)){
							while($row=$result->fetch_assoc()){
								echo "<tr><td><input type='hidden' class='prod_id' value='".$row['id']."'><label for='click' class='click-me'><img src='".$row['img_path']."'id='img'></label></td>"
									."<td><input type='text' class='textarea name' value='".$row['name']."' style='outline:none; border:none; text-align:center;' readonly></td>"
									."<td><input type='text' class='textarea desc' value='".$row['description']."' style='outline:none; border:none; text-align:center;' readonly></td>"
									."<td><input type='text' class='textarea price' value='".$row['price']."' style='outline:none; border:none; text-align:center;' readonly></td>";
							}
						}
						
					?>
				</form>
			</tbody>
		</table>

		<form class="center" method="GET" action="query.php">
			<input type="checkbox" id="click">
			<div class="content">
				<div class="header">
					<input class="fontz" type="text" id="modal-header-product" name="modal-header-product">
					<input class="fontz" type="text" id="modal-header-desc" name="modal-header-desc">
					<input type="hidden" id="modal-header-id" name="modal-header-id">
				</div>
				<input class="position2 text-center fontz" type="text" id="modal-body-price" name="modal-body-price">
				<br>
				<input class="area position1" type="number" id="qty" name="modal-body-qty" size="3">
				<div class="line"></div>
				<label for="click" class="close-btn">Close</label>
				<input type="submit" class="add-btn" value="Add to cart">
			</div>
		</form>
		<script>
			var e = $('img[id=img]');
			$(e).click(function(){
				modal($(this).closest('tr').index());
			})
			function modal(index){
				var product_id = document.getElementsByClassName('prod_id')[index-1].value;
				var product = document.getElementsByClassName('name')[index-1].value;
				var description = document.getElementsByClassName('desc')[index-1].value;
				var price = document.getElementsByClassName('price')[index-1].value;

				document.getElementById('modal-header-id').value = product_id;
				document.getElementById('modal-header-product').value = product;
				document.getElementById('modal-header-desc').value = description;
				document.getElementById('modal-body-price').value = price;
				
				// console.log(product_id)
				// console.log(index)
				// console.log(product)
				// console.log(description
			}
		</script>
<?php include "footer.php";?>