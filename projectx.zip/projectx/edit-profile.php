<?php include "conn.php";?>
<!DOCTYPE html>
<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/profile.css">
		<link rel="stylesheet" href="css/footer.css">
	</head>
	<body>
		<a href="temp_prof.php"><img src="https://img.icons8.com/officel/80/000000/back.png"/></a>
		<div class="container">
			<div class="title">Edit your profile</div>
			<div class="content">
			<form action="query.php" method="GET">
				<?php
					$_SESSION['profile'] = "SELECT * FROM users WHERE id = ".$_SESSION['customer_id'].";";
				?>
				<div class="user-details">
					<div class="input-box">
						<span class="details">Full Name</span>
						<?php
							if($result=$mysqli->query($_SESSION['profile'])){
								while($row=$result->fetch_assoc()){
									echo "<input type='text' name='fname' placeholder='Enter your name' value='".$row['name']."' required>";
								}
							}
						?>
					</div>
					<div class="input-box">
						<span class="details">Username</span>
						<?php
							if($result=$mysqli->query($_SESSION['profile'])){
								while($row=$result->fetch_assoc()){
									echo "<input type='text' name='uname' placeholder='Enter your name' value='".$row['username']."' required>";
								}
							}
						?>
					</div>
					<div class="input-box">
						<span class="details">Phone number</span>
						<?php
							if($result=$mysqli->query($_SESSION['profile'])){
								while($row=$result->fetch_assoc()){
									echo "<input type='text' name='mobile' placeholder='Enter your name' value='".$row['mobile_number']."' required>";
								}
							}
						?>
					</div>
					<div class="input-box">
						<span class="details">Email</span>
						<?php
							if($result=$mysqli->query($_SESSION['profile'])){
								while($row=$result->fetch_assoc()){
									echo "<input type='text' name='email' placeholder='Enter your name' value='".$row['email']."' required>";
								}
							}
						?>
					</div>
					<div class="address">
						<span class="details">Address</span>
						<?php
							if($result=$mysqli->query($_SESSION['profile'])){
								while($row=$result->fetch_assoc()){
									echo "<input type='text' name='address' placeholder='Enter your name' value='".$row['address']."' required>";
								}
							}
						?>
					</div>
					<div class="input-box">
						<span class="details">Password</span>
						<?php
							if($result=$mysqli->query($_SESSION['profile'])){
								while($row=$result->fetch_assoc()){
									echo "<input type='password' name='password' placeholder='Enter your name' value='".$row['password']."' required>";
								}
							}
						?>
					</div>
				</div>
				<div class="gender-details">
				<input type="radio" name="gender" id="dot-1">
				<input type="radio" name="gender" id="dot-2">
				<input type="radio" name="gender" id="dot-3">
				<span class="gender-title">Gender</span>
				<div class="category">
					<label for="dot-1">
					<span class="dot one"></span>
					<span class="gender">Male</span>
				</label>
				<label for="dot-2">
					<span class="dot two"></span>
					<span class="gender">Female</span>
				</label>
				<label for="dot-3">
					<span class="dot three"></span>
					<span class="gender">Prefer not to say</span>
					</label>
				</div>
				</div>
				<div class="button">
				<input type="submit" value="Save">
				</div>
			</form>
			</div>
		</div>
	</body>
</html>