<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/admin-table.css">
		<link rel="stylesheet" href="css/footer.css">
	</head>
	<body>
		<?php include "navbar.php";?>
		<form action="query.php" action="GET" class="try">
			<table class="tb-data">
				<thead>
					<tr>
						<th  class="theadtd">Image</th>
						<th  class="theadtd">Product</th>
						<th  class="theadtd">Description</th>
						<th  class="theadtd">Quantity</th>
						<th  class="theadtd">Price</th>
						<th  class="theadtd">Total</th>
						<th  class="theadtd">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$sql ="SELECT product_id as prod_id, product.img_path as img_path, product.name as product, product.description as description, cart.qty as qty, cart.price as price FROM cart LEFT JOIN product ON (product.id = cart.product_id) WHERE cart.customer_id = ".$_SESSION['customer_id']." AND cart.state = 'draft'";
						if($result=$mysqli->query($sql)){
							$total = 0;
							$total_qty = 0;
							while($row=$result->fetch_assoc()){
								$sub_total = ($row['qty'] * $row['price']);
								$total += $sub_total;
								echo "<tr><td class='text-center 'theadtd''><input type='hidden' name='cart_prod_id' class='cart_prod_id' value='".$row['prod_id']."'><img src='".$row['img_path']."'></td>"
									."<td class='text-center theadtd'><input type='text' class='name' name='name' value='".$row['product']."' style='outline:none; border:none; text-align:center;' readable></td>"
									."<td class='text-center theadtd'><input type='text' class='desc' name='desc'value='".$row['description']."' style='outline:none; border:none; text-align:center;' readonly></td>"
									."<td class='text-center theadtd'><input type='text' class='quant' name='quant' value='".$row['qty']."' style='outline:none; border:none; text-align:center;' readonly></td>"
									."<td class='text-center theadtd'><input type='text' class='price' name='price' value='".$row['price']."' style='outline:none; border:none; text-align:center;' readonly></td>"
									."<td class='text-center theadtd'><input type='text' class='sub_total' name='sub_total' value='".$sub_total."' style='outline:none; border:none; text-align:center;' readonly></td>"
									."<td class='text-center theadtd'><a id='rem-anchor' class='table-anchor' href='query.php?remo=".$row['prod_id']."'>Remove<href></td></tr>";
									// ."<td><input type='text' size='6' maxlength='3' style='text-align:center';><td>"
									// ."<td><button onclick='addcart()' class='mod-add' type='submit'> Add to Cart </button></td></tr>";
							}
							
							echo "<tr><td></td>"."<td></td>"."<td></td>"."<td></td>"."<td></td>"."<td class='text-center'>Grand Total</td>"."<td class='text-center'><input type='text' class='total' name='total' value='".$total."' style='outline:none; border:none; text-align:center;' readonly></td></tr>";
						}
						?>
				</tbody>
			</table>
			<div class="text-right">
				<input type='submit' value='Checkout'>
			</div>
		</form>
		<?php include "footer.php";?>