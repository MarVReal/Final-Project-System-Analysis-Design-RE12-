<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/admin-table.css">
		<link rel="stylesheet" href="css/footer.css">
	</head>
	<body>
		<?php include "navbar.php";?>

		<table class="tb-data">
			<thead >
				<tr>
					<th class="theadtd">SO Number</th>
					<th class="theadtd">Customer</th>
					<th class="theadtd">Date Ordered</th>
					<th class="theadtd">Quantity</th>
					<th class="theadtd">Total</th>
					<th class="theadtd">Status</th>
					<th class="theadtd">Action</th>
				</tr>
			</thead>
			<tbody>
				<form action="query	.php" action="GET">
					<br>
					<?php
						$sql ="SELECT so.id so_id, so.so_number so_num, so.create_date order_date, users.name customer, so.qty quant, so.total total, so.status status FROM sale_order so LEFT JOIN users on users.id = so.customer_id WHERE so.status = 'Packed' ORDER BY so_id DESC";
						if($result=$mysqli->query($sql)){
							while($row=$result->fetch_assoc()){
								echo "<tr href><td><input type='hidden' name='trans_so_id' class='trans_so_id' value='".$row['so_id']."'><span name='so-num' class='so-num' align='center' style='display:block;' onclick=\"window.location='sale_line_item.php?trans_so_id=".$row['so_id']."'\">".$row['so_num']."</span></td>"
									  ."<td class='theadtd'><span name='so-num' class='so-num' align='center' style='display:block;' onclick=\"window.location='sale_line_item.php?trans_so_id=".$row['so_id']."'\">".$row['customer']."</span></td>"
									  ."<td class='theadtd'><span name='so-num' class='so-num' align='center' style='display:block;' onclick=\"window.location='sale_line_item.php?trans_so_id=".$row['so_id']."'\">".$row['order_date']."</span></td>"
									  ."<td class='theadtd'><span name='so-num' class='so-num' align='center' style='display:block;' onclick=\"window.location='sale_line_item.php?trans_so_id=".$row['so_id']."'\">".$row['quant']."</span></td>"
									  ."<td class='theadtd'><span name='so-num' class='so-num' align='center' style='display:block;' onclick=\"window.location='sale_line_item.php?trans_so_id=".$row['so_id']."'\">".$row['total']."</span></td>"
									  ."<td class='theadtd'><span name='so-num' class='so-num' align='center' style='display:block;' onclick=\"window.location='sale_line_item.php?trans_so_id=".$row['so_id']."'\">".$row['status']."</span></td>"
									  ."<td class='theadtd'><a id='val-anchor' class='table-anchor' href='query.php?valid_pack=".$row['so_id']."'>Validate<href></td></tr>";
									  // ."<td><input type='text' size='6' maxlength='3' style='text-align:center';><td>"
									  // ."<td><button onclick='addcart()' class='mod-add' type='submit'> Add to Cart </button></td></tr>";
							}
						}
						// echo "<td><input type='submit' value='Checkout'></td></tr>"
					?>
				</form>
			</tbody>
		</table>


		<?php include "footer.php";?>