<?php
	session_start();

	$mysqli = @new mysqli('localhost','root','', 'projectx');
	if($mysqli->connect_errno){
		die('Connect Error' . $mysqli->connect_errno);
	}

	$_SESSION['sql']='';
	
?>