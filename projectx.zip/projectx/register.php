<?php include "conn.php";?>

<?php
	if(isset($_POST['register'])){
		if(isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])){
			$username = $_POST['username'];
			$email = $_POST['email'];
			$password = md5($_POST['password']);

			$Select = "SELECT email FROM users WHERE email = ? LIMIT 1;";
			$Insert = "INSERT INTO users(username, email, password) VALUES(?,?,?);";

			#Sanitize query for prevention of SQL Injection
			#PREPARED STATEMENT
			$stmt = $mysqli->prepare($Select);
			$stmt->bind_param("s", $email);
			$stmt->execute();
			$stmt->bind_result($resultEmail);
			$stmt->store_result();
			$stmt->fetch();
			$rnum = $stmt->num_rows;

			if ($rnum == 0) {
				$stmt->close();

				$stmt = $mysqli->prepare($Insert);
				$stmt->bind_param("sss",$username, $email, $password);
				if ($stmt->execute()) {
					echo "New record inserted sucessfully.";
					#do some stuffs
				}
				else {
					echo $stmt->error;
				}
			}
			else {
				echo '<script>alert("Email already taken")</script>';
			}
			$stmt->close();
		}
	}
?>
