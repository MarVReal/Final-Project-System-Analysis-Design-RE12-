<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/index.css">
		<link rel="stylesheet" href="css/footer.css">
	</head>
	<body>
		<?php include "navbar.php"?>

		<!-- Food Search Section Starts Here-->
		<section class="food-search text-center">
			<div class="container">
				<form action="sample.php" method="GET">
					<input type ="search" name="search" placeholder="Search for Food...">
					<input type ="submit" name="submit" value="Search" class="btn btn-primary">
				</form>
			</div>
		</section>

		<section class="categories">
			<div class="container">
				<h2 class="text-center">Categories</h2><br>
				<a href="#">
				<div class="box-3 float-container">
					<img src="images\momo.jpg" alt="Dimsum Products" class="img-responsive img-curve">
					<h3 class="float-text text-white text-center">Dimsum Products</h3>
				</div>
				</a>

				<a href="#">
				<div class="box-3 float-container">
					<img src="images\pic1.jpg" alt="Dimsum Products" class="img-responsive img-curve">
					<h3 class="float-text text-white text-center">Frozen Berries</h3>
				</div>
				</a>
			
				<a href="#">
				<div class="box-3 float-container">
					<img src="images\s1.jpg" alt="Dimsum Products" class="img-responsive img-curve">
					<h3 class="float-text text-white text-center">Meat Products</h3>
				</div>
				</a>
				<div class="clearfix"></div>
			</div>
		</section>

		<section class="food-menu">
			<div class="container">
				<h2 class="text-center">Best Sellers</h2><br><br><br>
				<div class="food-menu-box">
					<div class="food-menu-img">
						<img src="images\bangers.jpg" alt="Beef Bangers" class="img-responsive img-curve">
					</div>

					<div class="food-menu-desc">
						<h4>Beef Bangers</h4>
						<p class="food-price">₱299</p>
						<p class="food-detail">
							Traditional Scottish beef sausage links seasoned with a blend of spices.
						</p>
						<br>

						<a href="#" class ="btn btn-primary">Order Now!</a>
					</div>

					<div class="clearfix"></div>
				</div>
				<div class="food-menu-box">
					<div class="food-menu-img">
						<img src="images\mixedberz.jpeg" alt="Mixed Berries" class="img-responsive img-curve">
					</div>

					<div class="food-menu-desc">
						<h4>Mixed Berries</h4>
						<p class="food-price">₱299</p>
						<p class="food-detail">
							Mixture of raspberry, strawberry, cranberry and blueberry.
						</p>
						<br>

						<a href="#" class ="btn btn-primary">Order Now!</a>
					</div>

					<div class="clearfix"></div>
				</div>
				<div class="food-menu-box">
					<div class="food-menu-img">
						<img src="images\brat.jpg" alt="All-beef Bratwurst" class="img-responsive img-curve">
					</div>

					<div class="food-menu-desc">
						<h4>All-beef Bratwurst</h4>
						<p class="food-price">₱299</p>
						<p class="food-detail">
							Made of pork and veal, flavored with seasonings like caraway, coriander, and nutmeg.
						</p>
						<br>

						<a href="#" class ="btn btn-primary">Order Now!</a>
					</div>

					<div class="clearfix"></div>
				</div>
				<div class="food-menu-box">
					<div class="food-menu-img">
						<img src="images\cranberry.jpeg" alt="Cranberry" class="img-responsive img-curve">
					</div>

					<div class="food-menu-desc">
						<h4>Cranberries</h4>
						<p class="food-price">₱299</p>
						<p class="food-detail">
							High in nutrients and antioxidants. Best if blended into smoothie.
						</p>
						<br>

						<a href="#" class ="btn btn-primary">Order Now!</a>
					</div>

					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
		</section>

		<section class="gmaps">
			<div class="container text-center">
				<h4 class="text-center">Our Location</h4><br>
				<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3861.849441053188!2d120.99283100000001!3d14.550601000000002!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c9613652cdf5%3A0xab52ee7a3617e31c!2s2185%20F.B.%20Harrison%20St%2C%20Pasay%2C%20Metro%20Manila!5e0!3m2!1sen!2sph!4v1623547524014!5m2!1sen!2sph" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			</div>
		</section>

<?php include "footer.php";?>