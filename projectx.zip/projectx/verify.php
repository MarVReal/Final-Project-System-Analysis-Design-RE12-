<?php include "conn.php";?>
<?php
	if(isset($_GET['username'])&&isset($_GET['password'])){
		$sql = "SELECT * FROM users WHERE username = ? AND password=? LIMIT 1";
		$sql2 = "SELECT * FROM users WHERE username = '".$_GET['username']."' AND password='".$_GET['password']."' LIMIT 1";
		$exist = false;
		$admin = 0;

		if($result=$mysqli->query($sql2)){

			while($row=$result->fetch_assoc()){
				$_SESSION['admin'] = $row['is_customer'];
				$_SESSION['customer_id'] = $row['id'];
			}
		}

		if($stmt=$mysqli->prepare($sql)){
			$stmt->bind_param("ss",$_GET['username'],$_GET['password']);
			$stmt->execute();
			$stmt->store_result();

			if(($stmt->num_rows)==1){
				$exist = true;

			}
		}
		$_SESSION['verify']=$exist;

		if($_SESSION['verify'] && $_SESSION['admin']==0)
			header("Location: transaction.php");
		elseif ($_SESSION['verify'] && $_SESSION['admin']==1) 
			header("Location: index.php");
		else
			header("Location: login.php");
	}
?>