<?php include "conn.php";?>
<!DOCTYPE html>
	<head>
		<link rel="stylesheet" href="css/navbar.css">
		<link rel="stylesheet" href="css/about.css">
		<link rel="stylesheet" href="css/footer.css">
		<link rel="stylesheet" href="css/style.css">
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Roboto+Slab:wght@900&display=swap" rel="stylesheet">
	</head>
	<body>
		<?php include "navbar.php"?>
		<section>
			<div class ="nav.container">
				<h2 class="text-center about">About Us</h2><br>
				<p class="text-center abouthead">Frozen Goodies MNL<br></p>
				<p class="text-center aboutdesc">A Premier Food Delivery Service<br></p><br>
				<p class="text-center aboutbody margin">Whether you’re prepping for a party or just want to keep your fridge full for the week,
					or have the most stable supply of frozen goods, we’ve got you covered with all the freshest food products available.
					A staple in the Metro Manilla community, we’re here to offer you unparalleled service, at unbeatable prices.<br></p>
			</div>
   		 </section>


<?php include "footer.php";?>